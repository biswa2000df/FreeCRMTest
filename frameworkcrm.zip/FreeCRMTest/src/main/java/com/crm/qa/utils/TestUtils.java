package com.crm.qa.utils;

import java.io.IOException;

import com.crm.qa.base.TestBase;

public class TestUtils extends TestBase {
	
	public TestUtils() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
	public static long PAGE_LODE_TIMEOUT=20;
	public static long IMPLICITY_WAIT=10;
	
	
	public void frameSwitch() {
		
		driver.switchTo().frame(0);
		
		
	}

}
